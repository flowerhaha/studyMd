var obj={"name":"li","age":18,"job":"sss"};
obj["name"]
for(var aa in obj){
   console.log(aa);
   obj[aa]
}