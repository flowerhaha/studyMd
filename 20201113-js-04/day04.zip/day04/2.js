

// var num=2;
// while(num>3){
//    console.log(num);
// }
// var num=4;
// do{
//  console.log(num);
// }while(num>3);