/* 
 1) 求两个数之和

*/

function total(x,y){
   return x+y;
}
var res=total(3,2);
console.log(res);

