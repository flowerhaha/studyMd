
/* 
同步
异步
 定时器是异步的，先走同步
*/
var time1=setTimeout(function(){
    console.log("hehe");
});

console.log(5);


